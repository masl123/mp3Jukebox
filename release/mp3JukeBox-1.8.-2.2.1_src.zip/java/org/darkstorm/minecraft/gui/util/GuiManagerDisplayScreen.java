package org.darkstorm.minecraft.gui.util;

import java.awt.Rectangle;
import java.io.IOException;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;

import org.darkstorm.minecraft.gui.GuiManager;
import org.darkstorm.minecraft.gui.component.*;
import org.lwjgl.opengl.GL11;

public class GuiManagerDisplayScreen extends GuiScreen {
	protected final GuiManager guiManager;

	public GuiManagerDisplayScreen(GuiManager guiManager) {
		this.guiManager = guiManager;
	}

	
	

	protected void mouseClicked(int x, int y, int button) throws IOException {
		super.mouseClicked(x, y, button); // This line throws IOException which is why this method has to have the 'throws' declaration
		
		for(Frame frame : guiManager.getFrames()) {
			if(!frame.isVisible())
				continue;
			if(!frame.isMinimized() && !frame.getArea().contains(x, y)) {
				for(Component component : frame.getChildren()) {
					for(Rectangle area : component.getTheme().getUIForComponent(component).getInteractableRegions(component)) {
						if(area.contains(x - frame.getX() - component.getX(), y - frame.getY() - component.getY())) {
							frame.onMousePress(x - frame.getX(), y - frame.getY(), button);
							guiManager.bringForward(frame);
				
							return ;
						}
					}
				}
			}
		}
		for(Frame frame : guiManager.getFrames()) {
			if(!frame.isVisible())
				continue;
			if(!frame.isMinimized() && frame.getArea().contains(x, y)) {
				frame.onMousePress(x - frame.getX(), y - frame.getY(), button);
				guiManager.bringForward(frame);
				
				break;
			} else if(frame.isMinimized()) {
				for(Rectangle area : frame.getTheme().getUIForComponent(frame).getInteractableRegions(frame)) {
					if(area.contains(x - frame.getX(), y - frame.getY())) {
						frame.onMousePress(x - frame.getX(), y - frame.getY(), button);
						guiManager.bringForward(frame);
				
						return ;
					}
				}
			}
		}
		return;
	}

	@Override
	protected void mouseReleased(int x, int y, int button) {
		super.mouseReleased(x, y, button);
		for(Frame frame : guiManager.getFrames()) {
			if(!frame.isVisible())
				continue;
			if(!frame.isMinimized() && !frame.getArea().contains(x, y)) {
				for(Component component : frame.getChildren()) {
					for(Rectangle area : component.getTheme().getUIForComponent(component).getInteractableRegions(component)) {
						if(area.contains(x - frame.getX() - component.getX(), y - frame.getY() - component.getY())) {
							frame.onMouseRelease(x - frame.getX(), y - frame.getY(), button);
							guiManager.bringForward(frame);
							return;
						}
					}
				}
			}
		}
		for(Frame frame : guiManager.getFrames()) {
			if(!frame.isVisible())
				continue;
			if(!frame.isMinimized() && frame.getArea().contains(x, y)) {
				frame.onMouseRelease(x - frame.getX(), y - frame.getY(), button);
				guiManager.bringForward(frame);
				break;
			} else if(frame.isMinimized()) {
				for(Rectangle area : frame.getTheme().getUIForComponent(frame).getInteractableRegions(frame)) {
					if(area.contains(x - frame.getX(), y - frame.getY())) {
						frame.onMouseRelease(x - frame.getX(), y - frame.getY(), button);
						guiManager.bringForward(frame);
						return;
					}
				}
			}
		}
	}

	@Override
	public void drawScreen(int par2, int par3, float par4) {
	    
		super.drawScreen(par2, par3, par4);
		guiManager.render();
	}
}