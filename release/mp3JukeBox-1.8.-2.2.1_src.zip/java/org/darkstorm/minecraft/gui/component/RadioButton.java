package org.darkstorm.minecraft.gui.component;

public interface RadioButton extends Button, SelectableComponent {
}
