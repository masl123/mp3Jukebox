package org.darkstorm.minecraft.gui.component;

public interface TextComponent extends Component {
	public String getText();

	public void setText(String text);
}
