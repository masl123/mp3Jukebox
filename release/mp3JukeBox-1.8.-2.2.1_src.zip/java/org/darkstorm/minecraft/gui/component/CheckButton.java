package org.darkstorm.minecraft.gui.component;

public interface CheckButton extends Button, SelectableComponent {
}
