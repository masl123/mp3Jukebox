package org.darkstorm.minecraft.gui.component.basic;

import org.darkstorm.minecraft.gui.component.*;
import org.darkstorm.minecraft.gui.layout.LayoutManager;

public class BasicPanel extends AbstractContainer implements Panel {
	public BasicPanel() {
	}

	public BasicPanel(LayoutManager layoutManager) {
		setLayoutManager(layoutManager);
	}
}
