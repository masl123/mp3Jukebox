package org.darkstorm.minecraft.gui.component;

public interface Panel extends Container {
}
