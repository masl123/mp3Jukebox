package org.darkstorm.minecraft.gui.listener;

public interface ComponentListener {

}
