package com.masl.mp3JUKEBOX.network;

import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;

public class ClientMessageHandler implements IMessageHandler<RedstoneMessage,IMessage>{

	@Override
	public IMessage onMessage(RedstoneMessage message, MessageContext ctx) {
		//TODO HANDLE REDSTONE MESSAGE
		return null;
	}

}
