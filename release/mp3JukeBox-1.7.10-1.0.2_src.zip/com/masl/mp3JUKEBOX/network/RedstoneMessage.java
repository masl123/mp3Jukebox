package com.masl.mp3JUKEBOX.network;

import javax.lang.model.type.PrimitiveType;

import io.netty.buffer.ByteBuf;
import cpw.mods.fml.common.network.simpleimpl.IMessage;

public class RedstoneMessage implements IMessage{
	
	public RedstoneMessage(){}
	
	public int x;
	public int y;
	public int z; 
	public int strenght; 
	
	public RedstoneMessage(int x,int y,int z, int strenght){
		this.x=x;
		this.y=y;
		this.z=z;
		this.strenght=strenght;
	}
	
	@Override
	public void fromBytes(ByteBuf buf) {
		x = buf.getInt(0);
		y= buf.getInt(4);
		z = buf.getInt(8);
		strenght = buf.getInt(12);
	}

	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(x);
		buf.writeInt(y);
		buf.writeInt(z);
		buf.writeInt(strenght);
	}

}
