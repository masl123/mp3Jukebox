 /*
  * mp3JukeBox - a mp3 Player Mod for Minecraft
  * Copyright (C) 2014 masll (minecraftforum.net)
  * 
  * This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  */


package com.masl.mp3JUKEBOX;

import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.lwjgl.util.Rectangle;

import com.google.common.collect.Multimap;
import com.masl.mp3JUKEBOX.network.RedstoneMessage;

import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
import cpw.mods.fml.common.network.NetworkRegistry.TargetPoint;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import paulscode.sound.IStreamListener;
import paulscode.sound.SoundSystem;
import paulscode.sound.SoundSystemConfig;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.ISound.AttenuationType;
import net.minecraft.client.audio.PositionedSound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.audio.SoundManager;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.Explosion;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class mp3JukeboxBlock extends Block {

	private String currUUID;
	protected static boolean soundPlaying = false;
	private SoundSystem sndSystem;
	private long timeLastClicked = 0;
	
	
	protected mp3JukeboxBlock(Material mat) {
		super(mat);
	}

	
	@Override
	public void onNeighborBlockChange(World world, int x,int y, int z, Block block) {
		if(mp3Jukebox.currSide==Side.CLIENT){
			getsndSystem();	
			if(block.canProvidePower()){
					if(world.getBlockPowerInput(x, y, z)==0){
						if (soundPlaying) {
							stopSound();
						}
					}else{
						if (!soundPlaying) {
							try {
								synchronized(Minecraft.getMinecraft().getSoundHandler()){
									mp3Jukebox.soundloader.stopCurrSound();
									playSound();
								}
							} catch (Exception e) {
								
								e.printStackTrace();
							}
						}
					}
				}
			}else{
				//Multiplayer
				if(block.canProvidePower()){
					mp3Jukebox.wrapper.sendToAll(new RedstoneMessage(x,y,z,world.getBlockPowerInput(x, y, z)));
				}
			}
		
		super.onNeighborBlockChange(world, x, y, z,block);
	}
	
	@SideOnly(Side.CLIENT)
	public void setVolume(float volume){
		synchronized(Minecraft.getMinecraft().getSoundHandler()){
			getsndSystem();
			sndSystem.setVolume(currUUID, volume);
		}
	}
	
	@Override
    public void onBlockAdded(World world, int x, int y, int z)
    {
        super.onBlockAdded(world, x, y, z);
        rotateBlock(world, x,  y, z);
    }
	
	public void rotateBlock(World world, int x, int y, int z){
		if (!world.isRemote){
			 	Block block = world.getBlock(x, y, z - 1);
	            Block block1 = world.getBlock(x, y, z + 1);
	            Block block2 = world.getBlock(x - 1, y, z);
	            Block block3 = world.getBlock(x + 1, y, z);
	            byte b0 = 3;
	            if (block.func_149730_j() && !block1.func_149730_j())
	            {
	                b0 = 3;
	            }
	            if (block1.func_149730_j() && !block.func_149730_j())
	            {
	                b0 = 2;
	            }
	            if (block2.func_149730_j() && !block3.func_149730_j())
	            {
	                b0 = 5;
	            }
	            if (block3.func_149730_j() && !block2.func_149730_j())
	            {
	                b0 = 4;
	            }
	            world.setBlockMetadataWithNotify(x, y, z, b0, 2);
		}
	}
	
	 public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack stack)
	    {
	        int l = MathHelper.floor_double((double)(entity.rotationYaw * 4.0F / 360.0F) + 0.5D) & 3;

	        if (l == 0)
	        {
	            world.setBlockMetadataWithNotify(x, y, z, 2, 2);
	        }

	        if (l == 1)
	        {
	            world.setBlockMetadataWithNotify(x, y, z, 5, 2);
	        }

	        if (l == 2)
	        {
	            world.setBlockMetadataWithNotify(x, y, z, 3, 2);
	        }

	        if (l == 3)
	        {
	            world.setBlockMetadataWithNotify(x, y, z, 4, 2);
	        }   
	 }
	 
	 
	@Override
	@SideOnly(Side.CLIENT)
	public void onBlockDestroyedByExplosion(World p_149723_1_, int p_149723_2_,int p_149723_3_, int p_149723_4_, Explosion p_149723_5_) {
		stopSound();
		super.onBlockDestroyedByExplosion(p_149723_1_, p_149723_2_, p_149723_3_,p_149723_4_, p_149723_5_);
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public void onBlockDestroyedByPlayer(World p_149664_1_, int p_149664_2_,int p_149664_3_, int p_149664_4_, int p_149664_5_) {
		stopSound();
		super.onBlockDestroyedByPlayer(p_149664_1_, p_149664_2_, p_149664_3_,p_149664_4_, p_149664_5_);
	}

	
	Rectangle play,stop,next,prev;
	private void createRect(int meta){
		if(meta == 2){//UP
			
			next = new Rectangle(0,0,499,499);
			prev = new Rectangle(500,0,500,499);
			play = new Rectangle(500,500,500,500);
			 stop = new Rectangle(0,500,499,500);
			
		}else if(meta==3){//DOWN
			play = new Rectangle(0,0,499,499);
			stop = new Rectangle(500,0,500,499);
			next = new Rectangle(500,500,500,500);
			prev = new Rectangle(0,500,499,500);
			
		}else if(meta==4){//LEFT
			
			prev = new Rectangle(0,0,499,499); 
			play = new Rectangle(500,0,500,499);
			stop = new Rectangle(500,500,500,500);
			next = new Rectangle(0,500,499,500); 
			
		}else if(meta==5){//RIGHT
			
			stop = new Rectangle(0,0,499,499); 
			next = new Rectangle(500,0,500,499);
			prev = new Rectangle(500,500,500,500); 
			play = new Rectangle(0,500,499,500);
			
		}else{
			play = new Rectangle(0,0,499,499);
			stop = new Rectangle(500,0,500,499);
			next = new Rectangle(500,500,500,500);
			prev = new Rectangle(0,500,499,500);
		}
		
	}
	
	@SideOnly(Side.CLIENT)
	private void doControls(double x, double y, double z){
		synchronized(Minecraft.getMinecraft().getSoundHandler()){
			int x1,y1,z1;
			x1= (int) (x*1000);
			y1 = (int) (y*1000);
			z1 = (int) (z*1000);
			
			if(play.contains(x1, z1)&&y==1.0){
				
	
				try {
					if (!soundPlaying) {
						mp3Jukebox.soundloader.stopCurrSound();
						playSound();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
			}else if(stop.contains(x1, z1)&&y==1.0){
				
				if (soundPlaying) {
					stopSound();
				}
				
				
				
				
				
				
			}else if(next.contains(x1, z1)&&y==1.0){
				
				if (soundPlaying) {
					stopSound();
				}
				
				if(titleindex+1<SoundLoader.music.size()){
					titleindex++;
				}else{
					titleindex=0;
				}
				
				try {
					if (!soundPlaying) {
						mp3Jukebox.soundloader.stopCurrSound();
						playSound();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}else if(prev.contains(x1, z1)&&y==1.0){
				
				if (soundPlaying) {
					stopSound();
				}
				
				if(titleindex-1>=0){
					titleindex--;
				}else{
					titleindex=SoundLoader.music.size()-1;
				}
				
				try {
					if (!soundPlaying) {
						mp3Jukebox.soundloader.stopCurrSound();
						playSound();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	
	@SideOnly(Side.CLIENT)
	private  void getsndSystem(){
		synchronized(Minecraft.getMinecraft().getSoundHandler()){
			try {
				
				
				//Field sndManagerField = SoundHandler.class.getDeclaredField("sndManager");
				
				
				Field[] soundHandlerfields = SoundHandler.class.getDeclaredFields();
				SoundManager manager = null;
				
				for(Field f : soundHandlerfields){
					f.setAccessible(true);
					Object o = f.get(Minecraft.getMinecraft().getSoundHandler());
					if(o instanceof SoundManager ){
						manager = (SoundManager) o;
						break;
					}
				}
				
				
				Field[] sndSystemFields = SoundManager.class.getDeclaredFields();
				for(Field f : sndSystemFields){
					f.setAccessible(true);
					Object o = f.get(manager);
					if(o instanceof SoundSystem ){
						sndSystem = (SoundSystem) o;
						break;
					}
				}
			
				//Field sndSystemField = SoundManager.class.getDeclaredField("sndSystem");
				//sndSystemField.setAccessible(true);
				//sndSystem = (SoundSystem) sndSystemField.get(manager);
				
			} catch (Exception e) {
				
				e.printStackTrace();
			} 
		}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	@SideOnly(Side.CLIENT)
	public boolean onBlockActivated(World world, final int x, final int y,final int z, EntityPlayer player, int blockside, float inx_,float iny_, float inz_) {
			
		
			
			getsndSystem();
			if((System.currentTimeMillis() - timeLastClicked)>200){

				// TODO do little Fields
					// TODO Implement Next and previus Song "Buttons"
						// TODO DO THIS SoundSystemConfig.addStreamListener(streamListener); for next title

				
				//DO SOMETHING
				if (BlockSide.indexof(blockside) == BlockSide.TOP) {
					
					createRect(world.getBlockMetadata(x, y, z));
					doControls(inx_,iny_,inz_);
					
				}	
				
				timeLastClicked = System.currentTimeMillis();
				world.markBlockForUpdate(x, y, z);
			}
		return true;
	}

	
	
	int titleindex = 0;
	@SideOnly(Side.CLIENT)
	private  void playSound() throws Exception {
		synchronized(Minecraft.getMinecraft().getSoundHandler()){
			if(SoundLoader.music!=null&&SoundLoader.music.size()!=0){
				stopSound();
				soundPlaying=true;
				currUUID = UUID.randomUUID().toString();
				sndSystem.backgroundMusic(currUUID, SoundLoader.music.get(titleindex).toURI().toURL(), SoundLoader.music.get(titleindex).getName(), false);
				
				sndSystem.setVolume(currUUID,  Minecraft.getMinecraft().gameSettings.getSoundLevel(SoundCategory.MUSIC));
				sndSystem.play(currUUID);
			}
		}
	}
	
	
	@SideOnly(Side.CLIENT)
	protected  void stopSound() {
		synchronized(Minecraft.getMinecraft().getSoundHandler()){
			if (currUUID != null && soundPlaying) {
				soundPlaying=false;
				sndSystem.stop(currUUID);
				sndSystem.removeSource(currUUID);
			}
		}
	}
	
	
	public IIcon[] icons = new IIcon[4];
	@Override
	public void registerBlockIcons(IIconRegister reg) {
	    for (int i = 0; i < icons.length; i ++) {
	        this.icons[i] = reg.registerIcon(this.textureName + "_" + i);
	    }
	}
	
	@Override
	public IIcon getIcon(int side, int meta) {
		if(side == 1 ){
			if(soundPlaying)
				return icons[2];
			else
				return icons[3];
		}else{
			return this.icons[0];
		}
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public int getRenderType() {
		return ClientProxy.blockRenderer;
	}
	
	@SideOnly(Side.CLIENT) 
	void addStreamListener(){	
			SoundSystemConfig.addStreamListener(new IStreamListener(){
				@Override
				public void endOfStream(String arg0, int arg1) {
					if(arg0!=null&&currUUID!=null&&currUUID.equals(arg0)&&soundPlaying){
						if (soundPlaying) {
							stopSound();
						}
						
						if(titleindex+1<SoundLoader.music.size()){
							titleindex++;
						}else{
							titleindex=0;
						}
						
						try {
							if (!soundPlaying) {
								mp3Jukebox.soundloader.stopCurrSound();
								playSound();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			});
		
	}
}

enum BlockSide {
	BOTTOM(0), TOP(1), NORTH(2), SOUTH(3), WEST(4), EAST(5);
	int i;
	BlockSide(int i) {
		this.i = i;
	}

	static BlockSide indexof(int i) {
		for (BlockSide s : BlockSide.values()) {
			if (i == s.i) {
				return s;
			}
		}
		return null;
	}

}
