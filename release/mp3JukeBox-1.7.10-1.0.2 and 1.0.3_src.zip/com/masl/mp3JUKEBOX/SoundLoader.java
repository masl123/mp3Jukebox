  /*
  * mp3JukeBox - a mp3 Player Mod for Minecraft
  * Copyright (C) 2015 masll (minecraftforum.net)
  * 
  * This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU Lesser General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU Lesser General Public License for more details.
  *
  *  You should have received a copy of the GNU Lesser General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  */

package com.masl.mp3JUKEBOX;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;










import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;

import paulscode.sound.SoundSystemConfig;
import paulscode.sound.SoundSystemException;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import de.cuina.fireandfuel.CodecJLayerMP3;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.client.audio.SoundEventAccessorComposite;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.audio.SoundList;
import net.minecraft.client.audio.SoundRegistry;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.GuiScreenEvent.ActionPerformedEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent17;
import net.minecraftforge.client.event.sound.SoundEvent;
import net.minecraftforge.client.event.sound.SoundLoadEvent;
import net.minecraftforge.client.event.sound.SoundSetupEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.event.world.WorldEvent.Unload;

public class SoundLoader {
	
	 
	public static List<File> music = new LinkedList();

	
	  @SubscribeEvent
	  @SideOnly(Side.CLIENT)
	  public void onSoundsLoaded(SoundLoadEvent SLEvent)
	  {
		 loadmusic();
	  }
	  
	  
	  @SideOnly(Side.CLIENT)
      public void loadmusic(){
  	   File musicfile = null;
         for(File f : Minecraft.getMinecraft().mcDataDir.listFiles()){
	           	if(f.getName().equals("music")&&f.isDirectory()&&f.exists()){
	           		musicfile=f;
	           		break;
	           	}
         }
         if(musicfile == null){
      	   mp3Jukebox.logger.log(Level.ERROR,"UNABLE TO FIND MUSIC FOLDER");
      	   return;
         }
         
        for(File m: musicfile.listFiles()){
     	   	if(FilenameUtils.getExtension(m.getAbsolutePath()).equals("ogg") || FilenameUtils.getExtension(m.getAbsolutePath()).equals("mp3")){
     	   		music.add(m);
     	   		mp3Jukebox.logger.log(Level.INFO,"FOUND SONG: "+m.getAbsolutePath());
     	   	}
        }
      }
	  
	  ISound currSound;
	  
	  @SubscribeEvent
	  @SideOnly(Side.CLIENT)
	  public void PlaySoundEvent(PlaySoundEvent17 event){
		  if( event.manager!=null && event.manager.sndHandler!=null && event.category == SoundCategory.MUSIC && mp3JukeboxBlock.soundPlaying){
			 
			  synchronized(Minecraft.getMinecraft().getSoundHandler()){
				  event.manager.sndHandler.stopSound(event.sound);
				  event.result = null;
				  mp3Jukebox.logger.log(Level.INFO,"Muting Ambient Music");
			  }
			  
		  }else if(event.manager!=null && event.manager.sndHandler!=null && event.category == SoundCategory.MUSIC){
			  currSound = event.sound;
			  
		  } 
	  }
	  
	  
	  public synchronized void stopCurrSound(){
		  if(currSound!=null){
			  mp3Jukebox.logger.log(Level.INFO,"Muting Ambient Music");
			  Minecraft.getMinecraft().getSoundHandler().stopSound(currSound);
			  currSound=null;
		  }
	  }
	  
	  
	  
	  
	  @SubscribeEvent
	  @SideOnly(Side.CLIENT)
	  public void soundsetup(SoundSetupEvent event){
		  try {
				SoundSystemConfig.setCodec("mp3", CodecJLayerMP3.class);
			} catch (SoundSystemException e) {
				e.printStackTrace();
			}
	  }
	  
	  @SubscribeEvent
	  @SideOnly(Side.CLIENT)
	  public void GUIConfigchanged(ActionPerformedEvent event){
		  if(event.gui instanceof GuiOptions){
			  synchronized(Minecraft.getMinecraft().getSoundHandler()){
				  ((mp3JukeboxBlock) mp3Jukebox.mp3JukeBox).setVolume(Minecraft.getMinecraft().gameSettings.getSoundLevel(SoundCategory.MUSIC));
			  }
		}
      }
	  
	  @SubscribeEvent
      @SideOnly(Side.CLIENT)
      public void FMLServerStopped(Unload event){
		        	 ((mp3JukeboxBlock)(mp3Jukebox.mp3JukeBox)).stopSound();
      }
	  
	  
}


















