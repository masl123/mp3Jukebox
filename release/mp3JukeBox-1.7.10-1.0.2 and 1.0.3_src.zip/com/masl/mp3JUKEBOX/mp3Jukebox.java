  /*
  * mp3JukeBox - a mp3 Player Mod for Minecraft
  * Copyright (C) 2014 masll (minecraftforum.net)
  * 
  * This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  */

package com.masl.mp3JUKEBOX;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.masl.mp3JUKEBOX.network.ClientMessageHandler;
import com.masl.mp3JUKEBOX.network.RedstoneMessage;

import paulscode.sound.SoundSystemConfig;
import paulscode.sound.SoundSystemException;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.SoundEventAccessorComposite;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.GuiScreenEvent.ActionPerformedEvent;
import net.minecraftforge.client.event.sound.SoundLoadEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.WorldEvent;
import cpw.mods.fml.client.event.ConfigChangedEvent;
import cpw.mods.fml.client.registry.RenderingRegistry;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler; // used in 1.6.2
//import cpw.mods.fml.common.Mod.PreInit;    // used in 1.5.2
//import cpw.mods.fml.common.Mod.Init;       // used in 1.5.2
//import cpw.mods.fml.common.Mod.PostInit;   // used in 1.5.2
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStoppedEvent;
import cpw.mods.fml.common.event.FMLServerStoppingEvent;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.common.registry.GameRegistry;
//import cpw.mods.fml.common.network.NetworkMod; // not used in 1.7
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import de.cuina.fireandfuel.CodecJLayerMP3;
import cpw.mods.fml.common.network.NetworkRegistry;

@Mod(modid="mp3Jukebox", name="mp3Jukebox", version="1.0.2")
//@NetworkMod(clientSideRequired=true) // not used in 1.7
public class mp3Jukebox {

	
		public static Logger logger = LogManager.getLogger();
		public static String MODID = "mp3Jukebox";
		public final static Block mp3JukeBox = new mp3JukeboxBlock(Material.wood).setHardness(2.0F).setStepSound(Block.soundTypeWood).setCreativeTab(CreativeTabs.tabDecorations).setBlockName("mp3Jukebox").setBlockTextureName(MODID+":jukebox");
		public final static Item EnderDisc = new Item().setTextureName(MODID+":enderdisc").setUnlocalizedName("enderDisc").setCreativeTab(CreativeTabs.tabMisc);
		public final static Block Speaker = new speakerBlock(Material.wood).setBlockTextureName(MODID+":speaker").setBlockName("speaker").setCreativeTab(CreativeTabs.tabDecorations).setHardness(2.0F).setStepSound(Block.soundTypeWood);
		public static SimpleNetworkWrapper wrapper;
		public final static SoundLoader soundloader = new SoundLoader();
		public static  Side currSide;
		
		
        // The instance of your mod that Forge uses.
        @Instance(value = "MODID")
        public static mp3Jukebox instance;
       
        // Says where the client and server 'proxy' code is loaded.
        @SidedProxy(clientSide="com.masl.mp3JUKEBOX.ClientProxy", serverSide="com.masl.mp3JUKEBOX.CommonProxy")
        public static CommonProxy proxy;
       
        @EventHandler // used in 1.6.2
        public void preInit(FMLPreInitializationEvent event) {
        	currSide = event.getSide();
        	wrapper = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        	if(event.getSide()==Side.CLIENT){
        		MinecraftForge.EVENT_BUS.register(soundloader);
        		wrapper.registerMessage(ClientMessageHandler.class, RedstoneMessage.class, 0, Side.CLIENT);
        	}
        }
       
        @EventHandler // used in 1.6.2
        public void load(FMLInitializationEvent event) {
        	
        	 mp3Jukebox.logger.log(Level.INFO,"LOADING "+ MODID);
        	 mp3Jukebox.logger.log(Level.INFO,"~~~~~~~~~~~~~~~~");

                proxy.registerRenderers();
                
                
               
                
                
                GameRegistry.registerBlock(mp3JukeBox, "mp3Jukebox");
                GameRegistry.registerItem(EnderDisc, "enderDisc");
                GameRegistry.registerBlock(Speaker, "speaker");
                GameRegistry.addShapedRecipe(new ItemStack(mp3JukeBox,1), new Object[]{
                		"WWW",
                		"SES",
                		"WRW",
                		'W',Blocks.planks,
                		'E',EnderDisc,
                		'R',Items.redstone,
                		'S',Speaker
                });
                
                GameRegistry.addShapedRecipe(new ItemStack(EnderDisc,1), new Object[]{
            		" G ",
            		"GEG",
            		" G ",
            		'G',Items.gold_ingot,
            		'E',Items.ender_eye,
                });
                
                GameRegistry.addShapedRecipe(new ItemStack(Speaker,1), new Object[]{
            		" WL",
            		"W L",
            		" WL",
            		'W',Blocks.planks,
            		'L',Items.leather,
                });
        }
        
       
        
        @EventHandler // used in 1.6.2
        @SideOnly(Side.CLIENT)
        //@PostInit   // used in 1.5.2
        public void postInit(FMLPostInitializationEvent event) {
        	((mp3JukeboxBlock) mp3Jukebox.mp3JukeBox).addStreamListener();
        }
        
        
       
       
        
        
       
        
       
}