package org.darkstorm.minecraft.gui.layout;

public interface Constraint {

}
