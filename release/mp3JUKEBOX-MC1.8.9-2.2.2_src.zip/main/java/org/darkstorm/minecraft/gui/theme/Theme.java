package org.darkstorm.minecraft.gui.theme;

import org.darkstorm.minecraft.gui.component.Component;

public interface Theme {
	public ComponentUI getUIForComponent(Component component);
}
